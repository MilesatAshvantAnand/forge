#include "main.h"
#include "lemlib/api.hpp"
#include "robotconfig.hpp"
#include "autons.hpp"
#include "intake.hpp"

// Drivetrain motor groups
pros::MotorGroup left_motors({-1, -2, -3}, pros::MotorGearset::blue);
pros::MotorGroup right_motors({4, 5, 6}, pros::MotorGearset::blue);

// Sensors
pros::Imu imu(10);
pros::Rotation horizontal_rotation(11);
pros::Rotation vertical_rotation(12);

// Tracking wheels for odometry
lemlib::TrackingWheel horizontal_tracking(&horizontal_rotation, lemlib::Omniwheel::NEW_2, -5.75);
lemlib::TrackingWheel vertical_tracking(&vertical_rotation, lemlib::Omniwheel::NEW_2, -2.5);

lemlib::Drivetrain drivetrain(
    &left_motors,
    &right_motors,
    TRACK_WIDTH,
    lemlib::Omniwheel::NEW_325,
    DRIVE_RPM,
    2 // horizontal drift
);

// Lateral PID controller
lemlib::ControllerSettings lateral_controller(
    LATERAL_KP,  // proportional gain
    0,           // integral gain
    LATERAL_KD,  // derivative gain
    3,           // anti windup
    1,           // small error range, inches
    100,         // small error timeout, ms
    3,           // large error range, inches
    500,         // large error timeout, ms
    20           // max acceleration (slew)
);

// Angular PID controller
lemlib::ControllerSettings angular_controller(
    ANGULAR_KP,
    0,
    ANGULAR_KD,
    3,
    1,
    100,
    3,
    500,
    0
);

lemlib::OdomSensors sensors(
    &vertical_tracking,
    nullptr,
    &horizontal_tracking,
    nullptr,
    &imu
);

lemlib::Chassis chassis(drivetrain, lateral_controller, angular_controller, sensors);

void initialize() {
    pros::lcd::initialize();
    chassis.calibrate();
    intake_init();
}

void autonomous() {
    run_selected_auton(chassis);
}

void opcontrol() {
    pros::Controller controller(pros::E_CONTROLLER_MASTER);
    while (true) {
        int leftY = controller.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);
        int rightX = controller.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_X);
        chassis.arcade(leftY, rightX);

        if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R1)) {
            intake_spin(12000);
        } else if (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R2)) {
            intake_spin(-12000);
        } else {
            intake_stop();
        }

        pros::delay(20);
    }
}
