#include "intake.hpp"
#include "robotconfig.hpp"
#include "pros/motors.hpp"

pros::Motor intake_motor(INTAKE_PORT, pros::MotorGearset::green);

void intake_init() {
    intake_motor.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
}

void intake_spin(int voltage) {
    // Anti-jam: reverse briefly if current spikes above stall threshold
    if (intake_motor.get_current_draw() > INTAKE_STALL_CURRENT) {
        intake_motor.move_voltage(-voltage);
        pros::delay(150);
    }
    intake_motor.move_voltage(voltage);
}

void intake_stop() {
    intake_motor.move_voltage(0);
}
