#include "autons.hpp"
#include "intake.hpp"
#include "lemlib/api.hpp"

// Selected autonomous routine (set by LCD selector)
int selected_auton = 0;

void auton_red_left(lemlib::Chassis& chassis) {
    chassis.setPose(-52, -32, 90);
    // Score preload on left mogo
    chassis.moveToPoint(-24, -24, 2000);
    intake_spin(12000);
    chassis.turnToHeading(45, 800);
    chassis.moveToPoint(-8, -8, 1500);
    intake_stop();
}

void auton_blue_right(lemlib::Chassis& chassis) {
    chassis.setPose(52, -32, 270);
    chassis.moveToPoint(24, -24, 2000);
    intake_spin(12000);
    chassis.turnToHeading(315, 800);
    chassis.moveToPoint(8, -8, 1500);
    intake_stop();
}

void auton_skills(lemlib::Chassis& chassis) {
    chassis.setPose(-60, 0, 90);
    // Collect rings across the field
    for (int i = 0; i < 3; i++) {
        chassis.moveToPoint(-24 + i * 24, 0, 2500);
        intake_spin(12000);
        pros::delay(500);
    }
    // Park
    chassis.moveToPoint(48, 48, 3000);
    intake_stop();
}

void run_selected_auton(lemlib::Chassis& chassis) {
    switch (selected_auton) {
        case 0: auton_red_left(chassis); break;
        case 1: auton_blue_right(chassis); break;
        case 2: auton_skills(chassis); break;
    }
}
