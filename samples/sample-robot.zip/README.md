# Team 99999X — High Stakes Robot Code

VEX V5 robot code built on PROS + LemLib.

- 6-motor blue cartridge drivetrain, 450 RPM
- 2-wheel odometry with IMU heading
- Anti-jam intake
- Three autonomous routines: red left, blue right, skills
