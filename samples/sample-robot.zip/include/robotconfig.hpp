#pragma once

// ─── Drivetrain geometry ─────────────────────────────
#define TRACK_WIDTH 12.5
#define DRIVE_RPM 450

// ─── Lateral (forward/back) PID gains ────────────────
constexpr double LATERAL_KP = 10.0;
constexpr double LATERAL_KD = 3.0;

// ─── Angular (turning) PID gains ─────────────────────
constexpr double ANGULAR_KP = 2.0;
constexpr double ANGULAR_KD = 10.0;

// ─── Intake ──────────────────────────────────────────
#define INTAKE_PORT 7
#define INTAKE_STALL_CURRENT 2200

// ─── Odometry offsets (inches) ───────────────────────
constexpr double HORIZONTAL_WHEEL_OFFSET = -5.75;
constexpr double VERTICAL_WHEEL_OFFSET = -2.5;
