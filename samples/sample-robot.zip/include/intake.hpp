#pragma once

void intake_init();
void intake_spin(int voltage);
void intake_stop();
