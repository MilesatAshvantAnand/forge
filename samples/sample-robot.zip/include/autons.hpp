#pragma once
#include "lemlib/api.hpp"

extern int selected_auton;

void auton_red_left(lemlib::Chassis& chassis);
void auton_blue_right(lemlib::Chassis& chassis);
void auton_skills(lemlib::Chassis& chassis);
void run_selected_auton(lemlib::Chassis& chassis);
